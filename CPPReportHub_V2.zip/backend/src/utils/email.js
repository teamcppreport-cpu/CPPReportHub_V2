
const nodemailer = require('nodemailer');

let transporter;

function getTransporter() {
  if (transporter) return transporter;

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });

  return transporter;
}

async function sendOtpMail(to, code, subject = 'Your CPP Report Hub Verification Code') {
  const t = getTransporter();

  const html = `
    <div style="font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; padding: 16px;">
      <h2 style="color:#e11d48; margin-bottom:8px;">CPP Report Hub</h2>
      <p>Hi,</p>
      <p>Your one-time verification code is:</p>
      <div style="font-size: 28px; font-weight:700; letter-spacing: 4px; margin: 16px 0; color:#111827;">
        ${code}
      </div>
      <p>This code will expire in 10 minutes. Please do not share it with anyone.</p>
      <p style="margin-top:24px; font-size:12px; color:#6b7280;">
        If you did not request this, you can ignore this email.
      </p>
    </div>
  `;

  await t.sendMail({
    from: process.env.MAIL_FROM || 'no-reply@cppreport.online',
    to,
    subject,
    html
  });
}

module.exports = { sendOtpMail };

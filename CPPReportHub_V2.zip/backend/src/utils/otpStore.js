
// Very simple in-memory OTP store for boilerplate / local dev.
// In production you would move this to Redis or short-lived Mongo documents.

const store = new Map(); // key: email, value: { code, expiresAt }

function setOtp(email, code, ttlMs = 10 * 60 * 1000) {
  store.set(email.toLowerCase(), {
    code,
    expiresAt: Date.now() + ttlMs
  });
}

function verifyOtp(email, code) {
  const entry = store.get(email.toLowerCase());
  if (!entry) return false;
  if (Date.now() > entry.expiresAt) {
    store.delete(email.toLowerCase());
    return false;
  }
  if (entry.code !== code) return false;
  store.delete(email.toLowerCase());
  return true;
}

module.exports = { setOtp, verifyOtp };

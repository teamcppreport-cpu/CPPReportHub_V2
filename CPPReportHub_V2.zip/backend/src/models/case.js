
const mongoose = require('mongoose');

/**
 * G1/G2/G3/G4 meaning (enforced mostly by UI + permissions logic):
 * G1 - Normal case visible to relevant admins & owner, student identity visible.
 * G2 - Semi-anonymous (future use).
 * G3 - Anonymous to admins: owner can see who submitted, admins see case but not student identity.
 * G4 - Internal admin-only group (notes / follow-ups), student cannot see internal comments.
 */

const evidenceSchema = new mongoose.Schema({
  filename: String,
  url: String, // for now we store base64-less URL (e.g. Cloudinary / S3). In this boilerplate, backend just stores metadata.
  uploadedAt: { type: Date, default: Date.now }
}, { _id: false });

const adminNoteSchema = new mongoose.Schema({
  admin: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  text: String,
  createdAt: { type: Date, default: Date.now }
}, { _id: false });

const caseSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  group: {
    type: String,
    enum: ['G1', 'G2', 'G3', 'G4'],
    default: 'G1'
  },

  // dynamic form answers (key/value)
  answers: mongoose.Schema.Types.Mixed,

  status: {
    type: String,
    enum: ['open', 'in_review', 'resolved'],
    default: 'open'
  },

  flags: {
    autoSpam: { type: Boolean, default: false },
    adminMarkedFake: { type: Boolean, default: false }
  },

  evidence: [evidenceSchema],

  // short summary admin fills when resolving
  resolutionSummary: {
    whoSolved: String,
    nextStep: String,
    difficulties: String
  },

  // admin internal notes
  adminNotes: [adminNoteSchema],

  createdIp: String
}, { timestamps: true });

module.exports = mongoose.model('Case', caseSchema);

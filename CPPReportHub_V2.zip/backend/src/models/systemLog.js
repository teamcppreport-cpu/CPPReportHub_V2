
const mongoose = require('mongoose');

const systemLogSchema = new mongoose.Schema({
  type: String, // 'LOGIN', 'REGISTER', 'CASE_STATUS_CHANGE', etc.
  actor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  actorEmail: String,
  actorRole: String,
  ip: String,
  userAgent: String,
  details: mongoose.Schema.Types.Mixed
}, { timestamps: true });

module.exports = mongoose.model('SystemLog', systemLogSchema);

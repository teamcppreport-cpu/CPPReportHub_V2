
const mongoose = require('mongoose');

const chatMessageSchema = new mongoose.Schema({
  roomId: { type: String, index: true },
  fromUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  toUser:   { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  senderRole: { type: String, enum: ['student', 'admin', 'owner', 'bot']},
  text: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('ChatMessage', chatMessageSchema);


// Central export so it's easy to import models
module.exports = {
  User: require('./user'),
  Case: require('./case'),
  ChatMessage: require('./chatMessage'),
  SystemLog: require('./systemLog')
};


const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, SystemLog } = require('../models');
const { sendOtpMail } = require('../utils/email');
const { setOtp, verifyOtp } = require('../utils/otpStore');

function logEvent(type, req, extra = {}) {
  try {
    SystemLog.create({
      type,
      actor: req.user?._id,
      actorEmail: req.user?.email,
      actorRole: req.user?.role,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      details: extra
    }).catch(() => {});
  } catch (e) {}
}

// Send OTP for registration
router.post('/register/send-otp', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ message: 'Email required' });

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  setOtp(email, code);
  try {
    await sendOtpMail(email, code, 'CPP Report Hub - Registration Code');
  } catch (err) {
    console.error('sendOtp error', err);
    return res.status(500).json({ message: 'Could not send email, check SMTP config' });
  }
  return res.json({ message: 'OTP sent' });
});

// Complete registration
router.post('/register/complete', async (req, res) => {
  try {
    const { firstName, lastName, email, password, otp } = req.body;
    if (!(firstName && lastName && email && password && otp)) {
      return res.status(400).json({ message: 'Missing fields' });
    }
    if (!verifyOtp(email, otp)) {
      return res.status(400).json({ message: 'Invalid or expired code' });
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) return res.status(400).json({ message: 'Email already registered' });

    const username = (firstName + lastName).replace(/\s+/g, '').toLowerCase();
    const passwordHash = await bcrypt.hash(password, 12);

    const user = await User.create({
      firstName,
      lastName,
      username,
      email: email.toLowerCase(),
      passwordHash,
      registerIp: req.ip,
      registerUserAgent: req.headers['user-agent']
    });

    await SystemLog.create({
      type: 'REGISTER',
      actor: user._id,
      actorEmail: user.email,
      actorRole: user.role,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      details: {}
    });

    return res.json({ message: 'Registered, you can now log in.' });
  } catch (err) {
    console.error('register error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

// Send login OTP and validate password
router.post('/login/start', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user || user.isDeleted) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setOtp(email, code);

    try {
      await sendOtpMail(email, code, 'CPP Report Hub - Login Code');
    } catch (err) {
      console.error('sendOtp login error', err);
      return res.status(500).json({ message: 'Could not send email, check SMTP config' });
    }

    return res.json({ message: 'OTP sent' });
  } catch (err) {
    console.error('login start error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

// Complete login
router.post('/login/complete', async (req, res) => {
  try {
    const { email, otp, rememberMe } = req.body;
    if (!verifyOtp(email, otp)) {
      return res.status(400).json({ message: 'Invalid or expired code' });
    }
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user || user.isDeleted) {
      return res.status(400).json({ message: 'Invalid user' });
    }

    user.lastLoginIp = req.ip;
    user.lastLoginUserAgent = req.headers['user-agent'];
    user.lastActiveAt = new Date();
    await user.save();

    await SystemLog.create({
      type: 'LOGIN',
      actor: user._id,
      actorEmail: user.email,
      actorRole: user.role,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      details: { rememberMe: !!rememberMe }
    });

    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: rememberMe ? '30d' : '2h' }
    );

    res.cookie('token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      maxAge: rememberMe ? 30 * 24 * 60 * 60 * 1000 : 2 * 60 * 60 * 1000
    });

    return res.json({ message: 'Logged in', role: user.role });
  } catch (err) {
    console.error('login complete error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

// Get current user
router.get('/me', async (req, res) => {
  const token = req.cookies.token || (req.headers.authorization && req.headers.authorization.split(' ')[1]);
  if (!token) return res.json({ user: null });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.id).select('-passwordHash');
    if (!user) return res.json({ user: null });
    return res.json({ user });
  } catch {
    return res.json({ user: null });
  }
});

// Logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  return res.json({ message: 'Logged out' });
});

module.exports = router;


const router = require('express').Router();
const { authRequired } = require('../utils/authMiddleware');
const { ChatMessage, SystemLog, User } = require('../models');

// Very lightweight chat: stores messages per roomId (student-admin pair or student-bot)
router.get('/history/:roomId', authRequired, async (req, res) => {
  const msgs = await ChatMessage.find({ roomId: req.params.roomId }).sort({ createdAt: 1 }).limit(200);
  res.json({ messages: msgs });
});

router.post('/send', authRequired, async (req, res) => {
  const { roomId, toUserId, text } = req.body;
  if (!roomId || !text) return res.status(400).json({ message: 'Missing fields' });

  const msg = await ChatMessage.create({
    roomId,
    fromUser: req.user._id,
    toUser: toUserId || null,
    senderRole: req.user.role,
    text
  });

  await SystemLog.create({
    type: 'CHAT_MESSAGE',
    actor: req.user._id,
    actorEmail: req.user.email,
    actorRole: req.user.role,
    ip: req.ip,
    userAgent: req.headers['user-agent'],
    details: { roomId, textPreview: text.slice(0, 50) }
  });

  res.json({ message: 'Sent', msg });
});

// Simple AI-bot placeholder for students: rule-based Q&A
router.post('/bot/student', authRequired, async (req, res) => {
  const { prompt } = req.body;
  let answer = 'I am the CPP helper bot. I can answer questions about how to use this portal.';

  const lower = (prompt || '').toLowerCase();
  if (lower.includes('online') || lower.includes('leader')) {
    answer = 'Leaders are shown with a green dot when they were active in the last 2 minutes. If no one is online, you can still submit a case and they will see it later.';
  } else if (lower.includes('report') || lower.includes('form')) {
    answer = 'You can submit up to 2 reports per day. If this is an emergency and you need more, send a chat request to a leader.';
  } else if (lower.includes('website') || lower.includes('dashboard')) {
    answer = 'The website has a public overview, magazines and announcements. After login you see your student dashboard with cases, chat and profile.';
  } else if (lower.match(/love|crush|dating|romantic/)) {
    answer = 'I am not allowed to talk about romantic topics. Let us focus on safety and school-related concerns.';
  }

  // Log but mark as bot
  await ChatMessage.create({
    roomId: `bot-${req.user._id}`,
    fromUser: null,
    toUser: req.user._id,
    senderRole: 'bot',
    text: answer
  });

  res.json({ answer });
});

// Owner assistant bot placeholder (rule-based)
router.post('/bot/owner', authRequired, async (req, res) => {
  if (req.user.role !== 'owner') return res.status(403).json({ message: 'Forbidden' });
  const { prompt } = req.body;
  let answer = 'Owner helper bot here. I can suggest settings to change, but a real AI would require connecting an external API.';

  const lower = (prompt || '').toLowerCase();
  if (lower.includes('maintenance')) {
    answer = 'To enable maintenance mode, toggle it in the settings page. The backend should then only allow admins/owner to access dashboards and show a maintenance page to everyone else.';
  } else if (lower.includes('new feature')) {
    answer = 'For new features, you can keep notes in the owner dashboard and ask your developer to update the backend and frontend.';
  }

  res.json({ answer });
});

module.exports = router;


const router = require('express').Router();
const { authRequired, requireRole } = require('../utils/authMiddleware');
const { Case, User, SystemLog } = require('../models');

// Get all cases (admin/owner)
router.get('/cases', authRequired, requireRole(['admin','owner']), async (req, res) => {
  const cases = await Case.find().populate('student', 'username email role').sort({ createdAt: -1 });
  res.json({ cases });
});

// Change status and add resolution summary when resolved
router.post('/cases/:id/status', authRequired, requireRole(['admin','owner']), async (req, res) => {
  try {
    const { status, resolution } = req.body;
    const allowed = ['open','in_review','resolved'];
    if (!allowed.includes(status)) return res.status(400).json({ message: 'Invalid status' });

    const c = await Case.findById(req.params.id);
    if (!c) return res.status(404).json({ message: 'Case not found' });

    c.status = status;
    if (status === 'resolved' && resolution) {
      c.resolutionSummary = resolution;
    }
    await c.save();

    await SystemLog.create({
      type: 'CASE_STATUS_CHANGE',
      actor: req.user._id,
      actorEmail: req.user.email,
      actorRole: req.user.role,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      details: {
        caseId: c._id,
        newStatus: status,
        resolution
      }
    });

    res.json({ message: 'Updated', case: c });
  } catch (err) {
    console.error('status change error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin can grant +1 extra case allowance (we just log it; real logic to be added)
router.post('/students/:id/extra-case', authRequired, requireRole(['admin','owner']), async (req, res) => {
  const student = await User.findById(req.params.id);
  if (!student) return res.status(404).json({ message: 'Student not found' });

  await SystemLog.create({
    type: 'ADMIN_GRANT_EXTRA_CASE',
    actor: req.user._id,
    actorEmail: req.user.email,
    actorRole: req.user.role,
    ip: req.ip,
    userAgent: req.headers['user-agent'],
    details: { studentId: student._id, studentEmail: student.email }
  });

  // In real version you would store a counter on the user and check it in case creation.
  res.json({ message: 'Extra case permission recorded in logs (wire this to logic later)' });
});

// Get system logs (owner full, admin filtered)
router.get('/logs', authRequired, requireRole(['admin','owner']), async (req, res) => {
  const query = {};
  if (req.user.role === 'admin') {
    // admins see everything except stealth owner actions in a real system
  }
  const logs = await SystemLog.find(query).sort({ createdAt: -1 }).limit(500);
  res.json({ logs });
});

// Basic users list for owner
router.get('/users', authRequired, requireRole('owner'), async (req, res) => {
  const users = await User.find().sort({ createdAt: -1 });
  res.json({ users });
});

module.exports = router;

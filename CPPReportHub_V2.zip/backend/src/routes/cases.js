
const router = require('express').Router();
const { authRequired, requireRole } = require('../utils/authMiddleware');
const { Case, SystemLog } = require('../models');

// helper: count cases today for student
async function countTodayCases(studentId) {
  const start = new Date();
  start.setHours(0,0,0,0);
  const end = new Date();
  end.setHours(23,59,59,999);
  return Case.countDocuments({
    student: studentId,
    createdAt: { $gte: start, $lte: end }
  });
}

// Student creates a case (max 2/day by default)
router.post('/', authRequired, requireRole('student'), async (req, res) => {
  try {
    const user = req.user;
    const todayCount = await countTodayCases(user._id);
    const bypass = req.body.bypassLimit === true && user.role !== 'student'; // just in case

    if (todayCount >= 2 && !bypass) {
      return res.status(400).json({ message: 'Daily limit reached (2 cases). Contact a leader if this is an emergency.' });
    }

    const { group, answers } = req.body;
    const groupValue = ['G1','G2','G3','G4'].includes(group) ? group : 'G1';

    // super naive auto spam flag: very short text or repeated same text
    let autoSpam = false;
    const desc = (answers && (answers.description || answers.whatHappened)) || '';
    if (desc.length < 10) autoSpam = true;

    const newCase = await Case.create({
      student: user._id,
      group: groupValue,
      answers,
      createdIp: req.ip,
      flags: { autoSpam }
    });

    await SystemLog.create({
      type: 'CASE_CREATE',
      actor: user._id,
      actorEmail: user.email,
      actorRole: user.role,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      details: { caseId: newCase._id, group: groupValue }
    });

    res.json({ message: 'Case submitted', caseId: newCase._id, autoSpam });
  } catch (err) {
    console.error('case create error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Student sees own cases
router.get('/mine', authRequired, requireRole('student'), async (req, res) => {
  const cases = await Case.find({ student: req.user._id }).sort({ createdAt: -1 });
  res.json({ cases });
});

module.exports = router;
